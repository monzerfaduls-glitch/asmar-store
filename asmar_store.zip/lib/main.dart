import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'config/app_config.dart';
import 'screens/setup_needed.dart';
import 'screens/shell.dart';
import 'services/app_state.dart';
import 'theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (AppConfig.firebaseConfigured) {
    await Firebase.initializeApp(
      options: FirebaseOptions(
        apiKey: AppConfig.apiKey,
        appId: AppConfig.appId,
        messagingSenderId: AppConfig.senderId,
        projectId: AppConfig.projectId,
        storageBucket: AppConfig.storageBucket.isEmpty ? null : AppConfig.storageBucket,
      ),
    );
  }
  runApp(const AsmarApp());
}

class AsmarApp extends StatelessWidget {
  const AsmarApp({super.key});

  @override
  Widget build(BuildContext context) {
    final configured = AppConfig.firebaseConfigured;
    final app = MaterialApp(
      title: 'متجر أسمر',
      debugShowCheckedModeBanner: false,
      theme: buildTheme(),
      locale: const Locale('ar'),
      supportedLocales: const [Locale('ar')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      home: configured ? const Shell() : const SetupNeeded(),
    );
    if (!configured) return app;
    return ChangeNotifierProvider(create: (_) => AppState(), child: app);
  }
}
