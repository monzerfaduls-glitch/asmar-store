import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:url_launcher/url_launcher.dart';
import '../models.dart';
import '../screens/product_page.dart';
import '../services/db.dart';
import '../theme.dart';

void toast(BuildContext c, String m) {
  ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(m)));
}

Future<bool> confirmDialog(BuildContext c, String message) async {
  final r = await showDialog<bool>(
    context: c,
    builder: (_) => AlertDialog(
      content: Text(message),
      actions: [
        TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('إلغاء')),
        TextButton(onPressed: () => Navigator.pop(c, true), child: const Text('تأكيد')),
      ],
    ),
  );
  return r == true;
}

/// يحوّل الأرقام العربية ويقرأ رقمًا عشريًا.
double? parseNum(String s) {
  const ar = '٠١٢٣٤٥٦٧٨٩';
  var t = s.trim().replaceAll(',', '.').replaceAll('٫', '.');
  for (var i = 0; i < 10; i++) {
    t = t.replaceAll(ar[i], '$i');
  }
  return double.tryParse(t);
}

String fmtDate(DateTime? d) {
  if (d == null) return '';
  String two(int n) => n.toString().padLeft(2, '0');
  return '${d.year}/${two(d.month)}/${two(d.day)}  ${two(d.hour)}:${two(d.minute)}';
}

Future<void> openWhatsApp(BuildContext c, String number, String text) async {
  final n = number.replaceAll(RegExp(r'[^0-9]'), '');
  if (n.isEmpty) {
    toast(c, 'رقم واتساب غير مُعدّ بعد');
    return;
  }
  final uri = Uri.parse('https://wa.me/$n?text=${Uri.encodeComponent(text)}');
  var ok = false;
  try {
    ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {}
  if (!ok && c.mounted) toast(c, 'تعذّر فتح واتساب');
}

class Logo extends StatelessWidget {
  final double size;
  const Logo({super.key, this.size = 28});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        FittedBox(
          child: Directionality(
            textDirection: TextDirection.ltr,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text('ASMAR',
                    style: GoogleFonts.montserrat(
                        fontSize: size,
                        fontWeight: FontWeight.w900,
                        color: AppColors.gold,
                        letterSpacing: 3)),
                const SizedBox(width: 8),
                Text('STORE',
                    style: GoogleFonts.montserrat(
                        fontSize: size,
                        fontWeight: FontWeight.w300,
                        color: Colors.white,
                        letterSpacing: 3)),
              ],
            ),
          ),
        ),
        Text('متجر أسمر',
            style: TextStyle(color: AppColors.muted, fontSize: size * 0.45, letterSpacing: 1)),
      ],
    );
  }
}

class NetImage extends StatelessWidget {
  final String url;
  final BoxFit fit;
  final double? w;
  final double? h;
  const NetImage(this.url, {super.key, this.fit = BoxFit.cover, this.w, this.h});

  Widget _ph() => Container(
        width: w,
        height: h,
        color: AppColors.card2,
        child: const Center(child: Icon(Icons.image_outlined, color: AppColors.muted)),
      );

  @override
  Widget build(BuildContext context) {
    if (url.isEmpty) return _ph();
    return CachedNetworkImage(
      imageUrl: url,
      fit: fit,
      width: w,
      height: h,
      placeholder: (_, __) => _ph(),
      errorWidget: (_, __, ___) => _ph(),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  final VoidCallback? onMore;
  const SectionHeader({super.key, required this.title, this.onMore});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 10),
      child: Row(
        children: [
          Container(width: 4, height: 20, color: AppColors.gold),
          const SizedBox(width: 8),
          Expanded(
              child: Text(title,
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700))),
          if (onMore != null)
            TextButton(onPressed: onMore, child: const Text('عرض الكل')),
        ],
      ),
    );
  }
}

class EmptyState extends StatelessWidget {
  final String text;
  const EmptyState(this.text, {super.key});

  @override
  Widget build(BuildContext context) => Center(
        child: Padding(
          padding: const EdgeInsets.all(32),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Icon(Icons.inbox_outlined, size: 48, color: AppColors.muted),
              const SizedBox(height: 12),
              Text(text,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: AppColors.muted)),
            ],
          ),
        ),
      );
}

class ProductCard extends StatelessWidget {
  final Product p;
  const ProductCard(this.p, {super.key});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () => Navigator.push(
          context, MaterialPageRoute(builder: (_) => ProductPage(product: p))),
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.gold.withAlpha(40)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  ClipRRect(
                    borderRadius:
                        const BorderRadius.vertical(top: Radius.circular(18)),
                    child: NetImage(p.imageUrl),
                  ),
                  if (p.hasDiscount)
                    PositionedDirectional(
                      top: 8,
                      start: 8,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                        decoration: BoxDecoration(
                            color: AppColors.gold, borderRadius: BorderRadius.circular(8)),
                        child: Text('-${p.discountPercent}%',
                            style: const TextStyle(
                                color: Colors.black,
                                fontWeight: FontWeight.w800,
                                fontSize: 12)),
                      ),
                    ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                  const SizedBox(height: 4),
                  Wrap(
                    crossAxisAlignment: WrapCrossAlignment.center,
                    spacing: 6,
                    children: [
                      Text(Money.fmt(p.price),
                          style: const TextStyle(
                              color: AppColors.gold, fontWeight: FontWeight.w800)),
                      if (p.hasDiscount)
                        Text(Money.fmt(p.oldPrice!),
                            style: const TextStyle(
                                color: AppColors.muted,
                                fontSize: 11,
                                decoration: TextDecoration.lineThrough)),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class HProductList extends StatelessWidget {
  final List<Product> products;
  const HProductList({super.key, required this.products});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 235,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: products.length,
        separatorBuilder: (_, __) => const SizedBox(width: 12),
        itemBuilder: (_, i) => SizedBox(width: 155, child: ProductCard(products[i])),
      ),
    );
  }
}

class ProductsGrid extends StatelessWidget {
  final List<Product> products;
  const ProductsGrid(this.products, {super.key});

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final cols = (w / 180).floor().clamp(2, 5);
    return GridView.builder(
      padding: const EdgeInsets.all(16),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: cols,
        childAspectRatio: 0.72,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
      ),
      itemCount: products.length,
      itemBuilder: (_, i) => ProductCard(products[i]),
    );
  }
}

class StatusChip extends StatelessWidget {
  final String status;
  const StatusChip(this.status, {super.key});

  Color get color {
    switch (status) {
      case 'processing':
        return Colors.lightBlueAccent;
      case 'done':
        return Colors.greenAccent;
      case 'cancelled':
        return Colors.redAccent;
      default:
        return AppColors.gold;
    }
  }

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
        decoration: BoxDecoration(
          color: color.withAlpha(35),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: color.withAlpha(120)),
        ),
        child: Text(statusLabel(status),
            style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w700)),
      );
}

class OrderTile extends StatelessWidget {
  final AppOrder o;
  final VoidCallback onTap;
  final bool showUser;
  const OrderTile({super.key, required this.o, required this.onTap, this.showUser = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
              color: AppColors.card, borderRadius: BorderRadius.circular(16)),
          child: Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(o.ref,
                        style: const TextStyle(
                            color: AppColors.gold, fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text(o.productName, maxLines: 1, overflow: TextOverflow.ellipsis),
                    if (showUser && o.userName.isNotEmpty)
                      Text(o.userName,
                          style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                    Text(fmtDate(o.createdAt),
                        style: const TextStyle(color: AppColors.muted, fontSize: 12)),
                  ],
                ),
              ),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  StatusChip(o.status),
                  const SizedBox(height: 6),
                  Text(Money.fmt(o.total),
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// تفاصيل الطلب (تُستخدم في صفحة العميل وصفحة الإدارة)
class OrderInfo extends StatelessWidget {
  final AppOrder o;
  final bool admin;
  const OrderInfo({super.key, required this.o, this.admin = false});

  Widget _row(String k, String v) => v.isEmpty
      ? const SizedBox.shrink()
      : Padding(
          padding: const EdgeInsets.symmetric(vertical: 5),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(
                  width: 110,
                  child: Text(k, style: const TextStyle(color: AppColors.muted))),
              Expanded(child: Text(v)),
            ],
          ),
        );

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
          color: AppColors.card, borderRadius: BorderRadius.circular(16)),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                  child: Text(o.ref,
                      style: const TextStyle(
                          color: AppColors.gold,
                          fontWeight: FontWeight.w800,
                          fontSize: 16))),
              StatusChip(o.status),
            ],
          ),
          const Divider(height: 24),
          _row('التاريخ', fmtDate(o.createdAt)),
          if (admin) _row('العميل', o.userName),
          if (admin) _row('هاتف العميل', o.userPhone),
          _row('المنتج', o.productName),
          _row('الباقة', o.packLabel),
          _row('الكمية', '${o.quantity}'),
          _row('سعر الوحدة', Money.fmt(o.unitPrice)),
          _row('الإجمالي', Money.fmt(o.total)),
          _row('معرّف اللاعب', o.playerId),
          _row('طريقة الدفع', o.paymentMethod),
          _row('ملاحظات', o.notes),
          if (o.proofUrl.isNotEmpty) ...[
            const SizedBox(height: 12),
            const Text('إثبات الدفع', style: TextStyle(color: AppColors.muted)),
            const SizedBox(height: 6),
            ClipRRect(
              borderRadius: BorderRadius.circular(12),
              child: NetImage(o.proofUrl, h: 220, w: double.infinity, fit: BoxFit.cover),
            ),
          ],
        ],
      ),
    );
  }
}

/// حقل صورة: رفع من المعرض أو لصق رابط.
class ImageField extends StatefulWidget {
  final String initialUrl;
  final String folder;
  final ValueChanged<String> onChanged;
  const ImageField(
      {super.key, required this.initialUrl, required this.folder, required this.onChanged});

  @override
  State<ImageField> createState() => _ImageFieldState();
}

class _ImageFieldState extends State<ImageField> {
  late final TextEditingController _c = TextEditingController(text: widget.initialUrl);
  bool _busy = false;

  Future<void> _pick() async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 1280);
    if (x == null) return;
    setState(() => _busy = true);
    try {
      final path =
          'catalog/${widget.folder}/${DateTime.now().millisecondsSinceEpoch}.jpg';
      final url = await Db.uploadImage(x, path);
      _c.text = url;
      widget.onChanged(url);
    } catch (e) {
      if (mounted) toast(context, 'تعذّر رفع الصورة (تأكد من تفعيل Storage): $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ClipRRect(
          borderRadius: BorderRadius.circular(14),
          child: SizedBox(
              height: 150,
              width: double.infinity,
              child: NetImage(_c.text.trim())),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: _busy ? null : _pick,
          icon: _busy
              ? const SizedBox(
                  width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2))
              : const Icon(Icons.upload),
          label: const Text('رفع صورة من المعرض'),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _c,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(hintText: 'أو الصق رابط الصورة https://...'),
          onChanged: (v) {
            setState(() {});
            widget.onChanged(v.trim());
          },
        ),
      ],
    );
  }
}
