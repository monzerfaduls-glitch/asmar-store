import 'package:cloud_firestore/cloud_firestore.dart';

class Money {
  static String currency = '';
  static String fmt(double v) {
    final s = v == v.roundToDouble() ? v.toStringAsFixed(0) : v.toStringAsFixed(2);
    return currency.isEmpty ? s : '$s $currency';
  }
}

double _num(dynamic v) => v is num ? v.toDouble() : 0;
DateTime? _date(dynamic v) => v is Timestamp ? v.toDate() : null;

const orderStatuses = ['review', 'processing', 'done', 'cancelled'];

String statusLabel(String s) {
  switch (s) {
    case 'review':
      return 'قيد المراجعة';
    case 'processing':
      return 'قيد التنفيذ';
    case 'done':
      return 'مكتمل';
    case 'cancelled':
      return 'ملغي';
    default:
      return s;
  }
}

const productTypes = {
  'topup': 'شحن',
  'account': 'حساب للبيع',
  'service': 'خدمة رقمية',
};

class StoreSettings {
  final String whatsapp;
  final String currency;
  const StoreSettings({this.whatsapp = '', this.currency = ''});
  factory StoreSettings.fromMap(Map<String, dynamic>? m) => StoreSettings(
        whatsapp: m?['whatsapp']?.toString() ?? '',
        currency: m?['currency']?.toString() ?? '',
      );
}

class UserProfile {
  final String name;
  final String phone;
  final String email;
  const UserProfile({this.name = '', this.phone = '', this.email = ''});
  factory UserProfile.fromMap(Map<String, dynamic> m) => UserProfile(
        name: m['name']?.toString() ?? '',
        phone: m['phone']?.toString() ?? '',
        email: m['email']?.toString() ?? '',
      );
}

class Category {
  final String id;
  final String name;
  final String imageUrl;
  final int order;
  final bool active;
  const Category({
    required this.id,
    required this.name,
    this.imageUrl = '',
    this.order = 0,
    this.active = true,
  });
  factory Category.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return Category(
      id: d.id,
      name: m['name']?.toString() ?? '',
      imageUrl: m['imageUrl']?.toString() ?? '',
      order: (m['order'] as num?)?.toInt() ?? 0,
      active: m['active'] != false,
    );
  }
}

class Pack {
  final String label;
  final double price;
  const Pack({required this.label, required this.price});
  factory Pack.fromMap(Map<String, dynamic> m) =>
      Pack(label: m['label']?.toString() ?? '', price: _num(m['price']));
}

class Product {
  final String id;
  final String name;
  final String description;
  final String categoryId;
  final String type;
  final double price;
  final double? oldPrice;
  final String imageUrl;
  final bool requiresPlayerId;
  final bool featured;
  final bool topSeller;
  final bool active;
  final List<Pack> packages;
  final DateTime? createdAt;

  const Product({
    required this.id,
    required this.name,
    this.description = '',
    this.categoryId = '',
    this.type = 'topup',
    this.price = 0,
    this.oldPrice,
    this.imageUrl = '',
    this.requiresPlayerId = false,
    this.featured = false,
    this.topSeller = false,
    this.active = true,
    this.packages = const [],
    this.createdAt,
  });

  bool get hasDiscount => oldPrice != null && oldPrice! > price;
  int get discountPercent =>
      hasDiscount ? ((1 - price / oldPrice!) * 100).round() : 0;

  factory Product.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    final rawPacks = (m['packages'] as List?) ?? const [];
    return Product(
      id: d.id,
      name: m['name']?.toString() ?? '',
      description: m['description']?.toString() ?? '',
      categoryId: m['categoryId']?.toString() ?? '',
      type: m['type']?.toString() ?? 'topup',
      price: _num(m['price']),
      oldPrice: m['oldPrice'] is num ? (m['oldPrice'] as num).toDouble() : null,
      imageUrl: m['imageUrl']?.toString() ?? '',
      requiresPlayerId: m['requiresPlayerId'] == true,
      featured: m['featured'] == true,
      topSeller: m['topSeller'] == true,
      active: m['active'] != false,
      packages: rawPacks
          .map((e) => Pack.fromMap(Map<String, dynamic>.from(e as Map)))
          .toList(),
      createdAt: _date(m['createdAt']),
    );
  }
}

class PayMethod {
  final String id;
  final String name;
  final String instructions;
  final String account;
  final bool active;
  const PayMethod({
    required this.id,
    required this.name,
    this.instructions = '',
    this.account = '',
    this.active = true,
  });
  factory PayMethod.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return PayMethod(
      id: d.id,
      name: m['name']?.toString() ?? '',
      instructions: m['instructions']?.toString() ?? '',
      account: m['account']?.toString() ?? '',
      active: m['active'] == true,
    );
  }
}

class AppOrder {
  final String id;
  final String ref;
  final String userId;
  final String userName;
  final String userPhone;
  final String productName;
  final String packLabel;
  final int quantity;
  final double unitPrice;
  final double total;
  final String playerId;
  final String notes;
  final String paymentMethod;
  final String proofUrl;
  final String status;
  final DateTime? createdAt;

  const AppOrder({
    required this.id,
    required this.ref,
    required this.userId,
    required this.userName,
    required this.userPhone,
    required this.productName,
    required this.packLabel,
    required this.quantity,
    required this.unitPrice,
    required this.total,
    required this.playerId,
    required this.notes,
    required this.paymentMethod,
    required this.proofUrl,
    required this.status,
    required this.createdAt,
  });

  factory AppOrder.fromDoc(DocumentSnapshot<Map<String, dynamic>> d) {
    final m = d.data() ?? {};
    return AppOrder(
      id: d.id,
      ref: m['ref']?.toString() ?? d.id,
      userId: m['userId']?.toString() ?? '',
      userName: m['userName']?.toString() ?? '',
      userPhone: m['userPhone']?.toString() ?? '',
      productName: m['productName']?.toString() ?? '',
      packLabel: m['packLabel']?.toString() ?? '',
      quantity: (m['quantity'] as num?)?.toInt() ?? 1,
      unitPrice: _num(m['unitPrice']),
      total: _num(m['total']),
      playerId: m['playerId']?.toString() ?? '',
      notes: m['notes']?.toString() ?? '',
      paymentMethod: m['paymentMethod']?.toString() ?? '',
      proofUrl: m['proofUrl']?.toString() ?? '',
      status: m['status']?.toString() ?? 'review',
      createdAt: _date(m['createdAt']),
    );
  }
}
