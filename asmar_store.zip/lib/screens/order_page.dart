import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../services/db.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'order_detail_page.dart';

class OrderPage extends StatefulWidget {
  final Product product;
  final Pack? pack;
  final int qty;
  const OrderPage({super.key, required this.product, required this.pack, required this.qty});

  @override
  State<OrderPage> createState() => _OrderPageState();
}

class _OrderPageState extends State<OrderPage> {
  final _form = GlobalKey<FormState>();
  final _player = TextEditingController();
  final _notes = TextEditingController();
  PayMethod? _method;
  XFile? _proof;
  bool _busy = false;

  double get _unit => widget.pack?.price ?? widget.product.price;
  double get _total => _unit * widget.qty;

  @override
  void dispose() {
    _player.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickProof() async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 1600);
    if (x != null) setState(() => _proof = x);
  }

  Future<void> _submit() async {
    if (!_form.currentState!.validate()) return;
    final s = context.read<AppState>();
    final methods = s.activePayMethods;
    if (methods.isNotEmpty && _method == null) {
      toast(context, 'اختر وسيلة الدفع');
      return;
    }
    final p = widget.product;
    final summary = StringBuffer()
      ..writeln('المنتج: ${p.name}')
      ..writeln(widget.pack != null ? 'الباقة: ${widget.pack!.label}' : '')
      ..writeln('الكمية: ${widget.qty}')
      ..writeln('الإجمالي: ${Money.fmt(_total)}')
      ..writeln(p.requiresPlayerId ? 'معرّف اللاعب: ${_player.text.trim()}' : '')
      ..writeln(_method != null ? 'الدفع: ${_method!.name}' : '')
      ..write('\nهل تريد إرسال الطلب؟');
    final ok = await confirmDialog(context, summary.toString().replaceAll(RegExp(r'\n{2,}'), '\n'));
    if (!ok || !mounted) return;

    setState(() => _busy = true);
    try {
      final uid = s.user!.uid;
      var proofUrl = '';
      if (_proof != null) {
        proofUrl = await Db.uploadImage(
            _proof!, 'proofs/$uid/${DateTime.now().millisecondsSinceEpoch}.jpg');
      }
      final ref = Db.makeRef();
      final name = s.displayName;
      final phone = s.profile?.phone ?? '';
      final id = await Db.createOrder({
        'ref': ref,
        'userId': uid,
        'userName': name,
        'userPhone': phone,
        'productId': p.id,
        'productName': p.name,
        'packLabel': widget.pack?.label ?? '',
        'quantity': widget.qty,
        'unitPrice': _unit,
        'total': _total,
        'playerId': _player.text.trim(),
        'notes': _notes.text.trim(),
        'paymentMethod': _method?.name ?? '',
        'proofUrl': proofUrl,
      });
      if (!mounted) return;
      final lines = <String>[
        'طلب جديد من متجر أسمر',
        'الرقم المرجعي: $ref',
        'المنتج: ${p.name}',
        if (widget.pack != null) 'الباقة: ${widget.pack!.label}',
        'الكمية: ${widget.qty}',
        'الإجمالي: ${Money.fmt(_total)}',
        if (_player.text.trim().isNotEmpty) 'معرّف اللاعب: ${_player.text.trim()}',
        if (_method != null) 'طريقة الدفع: ${_method!.name}',
        if (_notes.text.trim().isNotEmpty) 'ملاحظات: ${_notes.text.trim()}',
        'الاسم: $name',
      ];
      await openWhatsApp(context, s.settings.whatsapp, lines.join('\n'));
      if (!mounted) return;
      Navigator.pushReplacement(context,
          MaterialPageRoute(builder: (_) => OrderDetailPage(orderId: id)));
    } catch (e) {
      if (mounted) toast(context, 'تعذّر إرسال الطلب: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final p = widget.product;
    final methods = s.activePayMethods;
    return Scaffold(
      appBar: AppBar(title: const Text('إتمام الطلب')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                  color: AppColors.card, borderRadius: BorderRadius.circular(16)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name,
                      style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                  if (widget.pack != null) Text('الباقة: ${widget.pack!.label}'),
                  Text('الكمية: ${widget.qty}'),
                  const Divider(height: 20),
                  Row(
                    children: [
                      const Text('الإجمالي'),
                      const Spacer(),
                      Text(Money.fmt(_total),
                          style: const TextStyle(
                              color: AppColors.gold,
                              fontWeight: FontWeight.w800,
                              fontSize: 18)),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            if (p.requiresPlayerId) ...[
              TextFormField(
                controller: _player,
                decoration: const InputDecoration(
                    labelText: 'معرّف اللاعب (ID)', prefixIcon: Icon(Icons.badge_outlined)),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'معرّف اللاعب مطلوب' : null,
              ),
              const SizedBox(height: 12),
            ],
            TextFormField(
              controller: _notes,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'ملاحظات إضافية (اختياري)'),
            ),
            const SizedBox(height: 20),
            const Text('وسيلة الدفع', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            if (methods.isEmpty)
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                    color: AppColors.card, borderRadius: BorderRadius.circular(12)),
                child: const Text(
                    'لم تُفعَّل وسائل دفع بعد. أرسل الطلب وسيتم الاتفاق على الدفع مع الإدارة عبر واتساب.',
                    style: TextStyle(color: AppColors.muted)),
              )
            else
              for (final m in methods)
                Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: InkWell(
                    borderRadius: BorderRadius.circular(14),
                    onTap: () => setState(() => _method = m),
                    child: Container(
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: AppColors.card,
                        borderRadius: BorderRadius.circular(14),
                        border: Border.all(
                            color: _method == m ? AppColors.gold : Colors.transparent),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Icon(
                                  _method == m
                                      ? Icons.check_circle
                                      : Icons.circle_outlined,
                                  color: AppColors.gold),
                              const SizedBox(width: 8),
                              Text(m.name,
                                  style: const TextStyle(fontWeight: FontWeight.w700)),
                            ],
                          ),
                          if (_method == m) ...[
                            if (m.instructions.isNotEmpty)
                              Padding(
                                padding: const EdgeInsets.only(top: 8),
                                child: Text(m.instructions,
                                    style: const TextStyle(color: AppColors.muted)),
                              ),
                            if (m.account.isNotEmpty)
                              Row(
                                children: [
                                  Expanded(
                                      child: SelectableText(m.account,
                                          style: const TextStyle(
                                              color: AppColors.gold,
                                              fontWeight: FontWeight.w700))),
                                  IconButton(
                                    icon: const Icon(Icons.copy, size: 18),
                                    onPressed: () {
                                      Clipboard.setData(ClipboardData(text: m.account));
                                      toast(context, 'تم النسخ');
                                    },
                                  ),
                                ],
                              ),
                          ],
                        ],
                      ),
                    ),
                  ),
                ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: _pickProof,
              icon: const Icon(Icons.attach_file),
              label: Text(_proof == null ? 'إرفاق إثبات الدفع (اختياري)' : 'تم اختيار صورة الإثبات'),
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                  color: AppColors.gold.withAlpha(25),
                  borderRadius: BorderRadius.circular(12)),
              child: const Text(
                  'لا تُرسل كلمة مرور حساب اللعبة أو بيانات تسجيل الدخول لأي أحد، ولن نطلبها منك أبدًا.',
                  style: TextStyle(fontSize: 12)),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _busy ? null : _submit,
              child: _busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                  : const Text('مراجعة وإرسال الطلب'),
            ),
          ],
        ),
      ),
    );
  }
}
