import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../widgets/common.dart';

class ProductsPage extends StatelessWidget {
  final String title;
  final bool Function(Product) filter;
  const ProductsPage({super.key, required this.title, required this.filter});

  @override
  Widget build(BuildContext context) {
    final list = context.watch<AppState>().activeProducts.where(filter).toList();
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: list.isEmpty
          ? const EmptyState('لا توجد منتجات هنا بعد')
          : ProductsGrid(list),
    );
  }
}
