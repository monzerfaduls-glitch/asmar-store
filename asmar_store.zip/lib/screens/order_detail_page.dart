import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../services/db.dart';
import '../widgets/common.dart';

class OrderDetailPage extends StatefulWidget {
  final String orderId;
  const OrderDetailPage({super.key, required this.orderId});

  @override
  State<OrderDetailPage> createState() => _OrderDetailPageState();
}

class _OrderDetailPageState extends State<OrderDetailPage> {
  bool _busy = false;

  Future<void> _attach(AppOrder o) async {
    final x = await ImagePicker()
        .pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 1600);
    if (x == null) return;
    setState(() => _busy = true);
    try {
      final url = await Db.uploadImage(
          x, 'proofs/${o.userId}/${DateTime.now().millisecondsSinceEpoch}.jpg');
      await Db.setProof(o.id, url);
      if (mounted) toast(context, 'تم رفع إثبات الدفع');
    } catch (e) {
      if (mounted) toast(context, 'تعذّر الرفع: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('تفاصيل الطلب')),
      body: StreamBuilder<AppOrder?>(
        stream: Db.orderStream(widget.orderId),
        builder: (context, snap) {
          if (snap.hasError) return EmptyState('تعذّر تحميل الطلب\n${snap.error}');
          if (!snap.hasData) {
            if (snap.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }
            return const EmptyState('الطلب غير موجود');
          }
          final o = snap.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              OrderInfo(o: o),
              const SizedBox(height: 16),
              if (o.status == 'review' && o.proofUrl.isEmpty)
                OutlinedButton.icon(
                  onPressed: _busy ? null : () => _attach(o),
                  icon: const Icon(Icons.attach_file),
                  label: const Text('إرفاق إثبات الدفع'),
                ),
              const SizedBox(height: 10),
              ElevatedButton.icon(
                onPressed: () => openWhatsApp(context, s.settings.whatsapp,
                    'مرحبًا، بخصوص طلبي رقم ${o.ref}'),
                icon: const Icon(Icons.support_agent),
                label: const Text('التواصل مع الدعم عبر واتساب'),
              ),
            ],
          );
        },
      ),
    );
  }
}
