import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'admin/admin_page.dart';
import 'auth_page.dart';
import 'payment_methods_page.dart';

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});

  Widget _item(IconData i, String t, VoidCallback f) => Container(
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
            color: AppColors.card, borderRadius: BorderRadius.circular(14)),
        child: ListTile(
          leading: Icon(i, color: AppColors.gold),
          title: Text(t),
          trailing: const Icon(Icons.chevron_left, color: AppColors.muted),
          onTap: f,
        ),
      );

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('حسابي')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
                color: AppColors.card, borderRadius: BorderRadius.circular(16)),
            child: s.user == null
                ? Column(
                    children: [
                      const Text('سجّل الدخول لإتمام الطلبات ومتابعتها'),
                      const SizedBox(height: 12),
                      ElevatedButton(
                        onPressed: () => Navigator.push(context,
                            MaterialPageRoute(builder: (_) => const AuthPage())),
                        child: const Text('تسجيل الدخول / إنشاء حساب'),
                      ),
                    ],
                  )
                : Row(
                    children: [
                      const CircleAvatar(
                          radius: 28,
                          backgroundColor: AppColors.gold,
                          child: Icon(Icons.person, color: Colors.black)),
                      const SizedBox(width: 14),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(s.displayName,
                                style: const TextStyle(
                                    fontWeight: FontWeight.w800, fontSize: 16)),
                            if ((s.profile?.phone ?? '').isNotEmpty)
                              Text(s.profile!.phone,
                                  style: const TextStyle(color: AppColors.muted)),
                            Text(s.user!.email ?? '',
                                style: const TextStyle(
                                    color: AppColors.muted, fontSize: 12)),
                          ],
                        ),
                      ),
                    ],
                  ),
          ),
          const SizedBox(height: 16),
          _item(Icons.payments_outlined, 'طرق الدفع', () {
            Navigator.push(context,
                MaterialPageRoute(builder: (_) => const PaymentMethodsPage()));
          }),
          _item(Icons.support_agent, 'التواصل مع الدعم الفني', () {
            openWhatsApp(context, s.settings.whatsapp, 'مرحبًا، أحتاج مساعدة بخصوص متجر أسمر');
          }),
          if (s.isAdmin)
            _item(Icons.admin_panel_settings, 'لوحة الإدارة', () {
              Navigator.push(
                  context, MaterialPageRoute(builder: (_) => const AdminPage()));
            }),
          if (s.user != null)
            _item(Icons.logout, 'تسجيل الخروج', () => s.signOut()),
        ],
      ),
    );
  }
}
