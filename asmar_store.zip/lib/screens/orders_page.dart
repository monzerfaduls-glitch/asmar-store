import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../services/db.dart';
import '../widgets/common.dart';
import 'auth_page.dart';
import 'order_detail_page.dart';

class OrdersPage extends StatelessWidget {
  const OrdersPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    return Scaffold(
      appBar: AppBar(title: const Text('طلباتي')),
      body: s.user == null
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('سجّل الدخول لمتابعة طلباتك السابقة وحالتها',
                        textAlign: TextAlign.center),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () => Navigator.push(context,
                          MaterialPageRoute(builder: (_) => const AuthPage())),
                      child: const Text('تسجيل الدخول'),
                    ),
                  ],
                ),
              ),
            )
          : StreamBuilder<List<AppOrder>>(
              stream: Db.ordersForUser(s.user!.uid),
              builder: (context, snap) {
                if (snap.hasError) return EmptyState('تعذّر تحميل الطلبات\n${snap.error}');
                if (!snap.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }
                final list = snap.data!;
                if (list.isEmpty) return const EmptyState('لا توجد طلبات سابقة');
                return ListView(
                  padding: const EdgeInsets.all(16),
                  children: [
                    for (final o in list)
                      OrderTile(
                        o: o,
                        onTap: () => Navigator.push(
                            context,
                            MaterialPageRoute(
                                builder: (_) => OrderDetailPage(orderId: o.id))),
                      ),
                  ],
                );
              },
            ),
    );
  }
}
