import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'products_page.dart';
import 'search_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  List<Widget> _section(BuildContext c, String title, List<Product> list) {
    if (list.isEmpty) return [];
    final ids = list.map((p) => p.id).toSet();
    return [
      SectionHeader(
        title: title,
        onMore: () => Navigator.push(
          c,
          MaterialPageRoute(
              builder: (_) =>
                  ProductsPage(title: title, filter: (p) => ids.contains(p.id))),
        ),
      ),
      HProductList(products: list.take(10).toList()),
    ];
  }

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    final ps = s.activeProducts;
    final recent = [...ps]..sort((a, b) =>
        (b.createdAt ?? DateTime(2000)).compareTo(a.createdAt ?? DateTime(2000)));
    final cats = s.categories.where((c) => c.active).toList();

    final children = <Widget>[
      const Padding(
        padding: EdgeInsets.fromLTRB(16, 16, 16, 12),
        child: Center(child: Logo()),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16),
        child: TextField(
          readOnly: true,
          onTap: () => Navigator.push(
              context, MaterialPageRoute(builder: (_) => const SearchPage())),
          decoration: const InputDecoration(
            hintText: 'ابحث عن لعبة أو منتج...',
            prefixIcon: Icon(Icons.search),
          ),
        ),
      ),
    ];

    if (s.error != null) {
      children.add(Container(
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
            color: Colors.red.withAlpha(30), borderRadius: BorderRadius.circular(12)),
        child: Text(
            'تعذّر تحميل بعض البيانات. تحقق من الاتصال وإعدادات Firebase وقواعد الأمان.\n${s.error}',
            style: const TextStyle(fontSize: 12)),
      ));
    }

    if (cats.isNotEmpty) {
      children.add(const SectionHeader(title: 'الأقسام'));
      children.add(SizedBox(
        height: 104,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: cats.length,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (_, i) {
            final c = cats[i];
            return InkWell(
              borderRadius: BorderRadius.circular(16),
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) => ProductsPage(
                        title: c.name, filter: (p) => p.categoryId == c.id)),
              ),
              child: SizedBox(
                width: 84,
                child: Column(
                  children: [
                    Container(
                      width: 62,
                      height: 62,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: AppColors.card,
                        border: Border.all(color: AppColors.gold.withAlpha(90)),
                      ),
                      child: ClipOval(
                        child: c.imageUrl.isEmpty
                            ? const Icon(Icons.sports_esports, color: AppColors.gold)
                            : NetImage(c.imageUrl),
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(c.name,
                        maxLines: 2,
                        textAlign: TextAlign.center,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 11)),
                  ],
                ),
              ),
            );
          },
        ),
      ));
    }

    children.addAll(_section(context, 'العروض المميزة', ps.where((p) => p.featured).toList()));
    children.addAll(_section(context, 'الألعاب الأكثر طلبًا', ps.where((p) => p.topSeller).toList()));
    children.addAll(_section(context, 'الخدمات الرقمية', ps.where((p) => p.type == 'service').toList()));
    children.addAll(_section(context, 'أحدث الحسابات المعروضة للبيع',
        recent.where((p) => p.type == 'account').toList()));
    children.addAll(_section(context, 'أُضيف حديثًا', recent));

    if (s.productsLoaded && ps.isEmpty) {
      children.add(const Padding(
        padding: EdgeInsets.only(top: 60),
        child: EmptyState('لا توجد منتجات حتى الآن. سيتم عرضها هنا فور إضافتها من لوحة الإدارة.'),
      ));
    }
    children.add(const SizedBox(height: 24));

    return SafeArea(child: ListView(children: children));
  }
}
