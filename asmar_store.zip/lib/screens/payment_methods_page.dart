import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';

class PaymentMethodsPage extends StatelessWidget {
  const PaymentMethodsPage({super.key});

  @override
  Widget build(BuildContext context) {
    final methods = context.watch<AppState>().activePayMethods;
    return Scaffold(
      appBar: AppBar(title: const Text('طرق الدفع')),
      body: methods.isEmpty
          ? const EmptyState('لم تُفعَّل وسائل دفع بعد. تواصل مع الدعم لمعرفة طرق الدفع المتاحة.')
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                for (final m in methods)
                  Container(
                    margin: const EdgeInsets.only(bottom: 12),
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                        color: AppColors.card, borderRadius: BorderRadius.circular(16)),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(m.name,
                            style: const TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 16)),
                        if (m.instructions.isNotEmpty) ...[
                          const SizedBox(height: 6),
                          Text(m.instructions, style: const TextStyle(color: AppColors.muted)),
                        ],
                        if (m.account.isNotEmpty)
                          Row(
                            children: [
                              Expanded(
                                  child: SelectableText(m.account,
                                      style: const TextStyle(
                                          color: AppColors.gold,
                                          fontWeight: FontWeight.w700))),
                              IconButton(
                                icon: const Icon(Icons.copy, size: 18),
                                onPressed: () {
                                  Clipboard.setData(ClipboardData(text: m.account));
                                  toast(context, 'تم النسخ');
                                },
                              ),
                            ],
                          ),
                      ],
                    ),
                  ),
                const Text('بعد التحويل، أرفق إثبات الدفع عند إنشاء الطلب وسيتم مراجعته يدويًا.',
                    style: TextStyle(color: AppColors.muted, fontSize: 12)),
              ],
            ),
    );
  }
}
