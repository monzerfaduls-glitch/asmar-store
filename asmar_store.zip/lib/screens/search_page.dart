import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../widgets/common.dart';

class SearchPage extends StatefulWidget {
  const SearchPage({super.key});

  @override
  State<SearchPage> createState() => _SearchPageState();
}

class _SearchPageState extends State<SearchPage> {
  String _q = '';

  @override
  Widget build(BuildContext context) {
    final all = context.watch<AppState>().activeProducts;
    final q = _q.trim().toLowerCase();
    final list = q.isEmpty
        ? all
        : all
            .where((p) =>
                p.name.toLowerCase().contains(q) ||
                p.description.toLowerCase().contains(q))
            .toList();
    return Scaffold(
      appBar: AppBar(
        title: TextField(
          autofocus: true,
          onChanged: (v) => setState(() => _q = v),
          decoration: const InputDecoration(
              hintText: 'ابحث عن لعبة أو منتج...', prefixIcon: Icon(Icons.search)),
        ),
      ),
      body: list.isEmpty ? const EmptyState('لا توجد نتائج') : ProductsGrid(list),
    );
  }
}
