import 'package:flutter/material.dart';
import '../../models.dart';
import '../../services/db.dart';
import '../../theme.dart';
import '../../widgets/common.dart';

class AdminOrdersTab extends StatefulWidget {
  const AdminOrdersTab({super.key});

  @override
  State<AdminOrdersTab> createState() => _AdminOrdersTabState();
}

class _AdminOrdersTabState extends State<AdminOrdersTab> {
  String _filter = 'all';
  late final Stream<List<AppOrder>> _stream = Db.allOrders();

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(
          height: 52,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            children: [
              for (final k in ['all', ...orderStatuses])
                Padding(
                  padding: const EdgeInsets.only(left: 8),
                  child: ChoiceChip(
                    label: Text(k == 'all' ? 'الكل' : statusLabel(k)),
                    selected: _filter == k,
                    selectedColor: AppColors.gold.withAlpha(60),
                    onSelected: (_) => setState(() => _filter = k),
                  ),
                ),
            ],
          ),
        ),
        Expanded(
          child: StreamBuilder<List<AppOrder>>(
            stream: _stream,
            builder: (context, snap) {
              if (snap.hasError) return EmptyState('تعذّر تحميل الطلبات\n${snap.error}');
              if (!snap.hasData) return const Center(child: CircularProgressIndicator());
              final list = snap.data!
                  .where((o) => _filter == 'all' || o.status == _filter)
                  .toList();
              if (list.isEmpty) return const EmptyState('لا توجد طلبات');
              return ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  for (final o in list)
                    OrderTile(
                      o: o,
                      showUser: true,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) => AdminOrderPage(orderId: o.id))),
                    ),
                ],
              );
            },
          ),
        ),
      ],
    );
  }
}

class AdminOrderPage extends StatelessWidget {
  final String orderId;
  const AdminOrderPage({super.key, required this.orderId});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('إدارة الطلب')),
      body: StreamBuilder<AppOrder?>(
        stream: Db.orderStream(orderId),
        builder: (context, snap) {
          if (snap.hasError) return EmptyState('${snap.error}');
          if (!snap.hasData) return const Center(child: CircularProgressIndicator());
          final o = snap.data!;
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              OrderInfo(o: o, admin: true),
              const SizedBox(height: 16),
              const Text('تغيير الحالة', style: TextStyle(fontWeight: FontWeight.w700)),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final k in orderStatuses)
                    ChoiceChip(
                      label: Text(statusLabel(k)),
                      selected: o.status == k,
                      selectedColor: AppColors.gold.withAlpha(60),
                      onSelected: (_) async {
                        try {
                          await Db.setStatus(o.id, k);
                        } catch (e) {
                          if (context.mounted) toast(context, 'تعذّر التحديث: $e');
                        }
                      },
                    ),
                ],
              ),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () => openWhatsApp(context, o.userPhone,
                    'مرحبًا ${o.userName}، بخصوص طلبك رقم ${o.ref} من متجر أسمر'),
                icon: const Icon(Icons.chat),
                label: const Text('مراسلة العميل عبر واتساب'),
              ),
            ],
          );
        },
      ),
    );
  }
}
