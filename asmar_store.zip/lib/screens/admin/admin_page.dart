import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/app_state.dart';
import 'admin_catalog.dart';
import 'admin_orders.dart';
import 'admin_products.dart';

/// الواجهة فقط تُخفي اللوحة عن غير المدراء؛ الحماية الفعلية في قواعد Firestore/Storage.
class AdminPage extends StatelessWidget {
  const AdminPage({super.key});

  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppState>();
    if (!s.isAdmin) {
      return Scaffold(
        appBar: AppBar(title: const Text('لوحة الإدارة')),
        body: const Center(child: Text('غير مصرّح لك بالدخول')),
      );
    }
    return DefaultTabController(
      length: 5,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('لوحة الإدارة'),
          bottom: const TabBar(
            isScrollable: true,
            tabs: [
              Tab(text: 'الطلبات'),
              Tab(text: 'المنتجات'),
              Tab(text: 'الأقسام'),
              Tab(text: 'الدفع'),
              Tab(text: 'الإعدادات'),
            ],
          ),
        ),
        body: const TabBarView(
          children: [
            AdminOrdersTab(),
            AdminProductsTab(),
            AdminCategoriesTab(),
            AdminPaymentsTab(),
            AdminSettingsTab(),
          ],
        ),
      ),
    );
  }
}
