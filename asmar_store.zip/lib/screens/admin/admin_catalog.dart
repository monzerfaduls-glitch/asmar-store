import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models.dart';
import '../../services/app_state.dart';
import '../../services/db.dart';
import '../../theme.dart';
import '../../widgets/common.dart';

// ======================= الأقسام =======================
class AdminCategoriesTab extends StatelessWidget {
  const AdminCategoriesTab({super.key});

  static const _defaults = [
    'شحن فري فاير Free Fire',
    'شحن ببجي موبايل PUBG Mobile',
    'شحن بيس eFootball',
    'خدمات كلاش أوف كلانس',
    'حسابات الألعاب للبيع',
    'خدمات تيك توك الرقمية',
  ];

  Future<void> _seed(BuildContext context) async {
    try {
      for (var i = 0; i < _defaults.length; i++) {
        await Db.saveCategory(null, {'name': _defaults[i], 'order': i, 'imageUrl': '', 'active': true});
      }
    } catch (e) {
      if (context.mounted) toast(context, 'تعذّر الإنشاء: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    final cats = context.watch<AppState>().categories;
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.gold,
        foregroundColor: Colors.black,
        onPressed: () => showDialog(context: context, builder: (_) => const CategoryDialog()),
        icon: const Icon(Icons.add),
        label: const Text('قسم جديد'),
      ),
      body: cats.isEmpty
          ? Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Text('لا توجد أقسام بعد', style: TextStyle(color: AppColors.muted)),
                    const SizedBox(height: 12),
                    OutlinedButton(
                      onPressed: () => _seed(context),
                      child: const Text('إنشاء الأقسام الافتراضية (بدون منتجات)'),
                    ),
                  ],
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
              itemCount: cats.length,
              itemBuilder: (_, i) {
                final c = cats[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                      color: AppColors.card, borderRadius: BorderRadius.circular(14)),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: SizedBox(width: 48, height: 48, child: NetImage(c.imageUrl)),
                    ),
                    title: Text(c.name),
                    subtitle: Text(c.active ? 'ظاهر' : 'مخفي',
                        style: const TextStyle(color: AppColors.muted)),
                    onTap: () => showDialog(
                        context: context, builder: (_) => CategoryDialog(category: c)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                      onPressed: () async {
                        if (!await confirmDialog(context, 'حذف القسم "${c.name}"؟')) return;
                        try {
                          await Db.deleteCategory(c.id);
                        } catch (e) {
                          if (context.mounted) toast(context, 'تعذّر الحذف: $e');
                        }
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class CategoryDialog extends StatefulWidget {
  final Category? category;
  const CategoryDialog({super.key, this.category});

  @override
  State<CategoryDialog> createState() => _CategoryDialogState();
}

class _CategoryDialogState extends State<CategoryDialog> {
  late final TextEditingController _name =
      TextEditingController(text: widget.category?.name ?? '');
  late final TextEditingController _order =
      TextEditingController(text: '${widget.category?.order ?? 0}');
  late String _image = widget.category?.imageUrl ?? '';
  late bool _active = widget.category?.active ?? true;
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _order.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      toast(context, 'اسم القسم مطلوب');
      return;
    }
    setState(() => _busy = true);
    try {
      await Db.saveCategory(widget.category?.id, {
        'name': _name.text.trim(),
        'order': int.tryParse(_order.text.trim()) ?? 0,
        'imageUrl': _image,
        'active': _active,
      });
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        toast(context, 'تعذّر الحفظ: $e');
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.category == null ? 'قسم جديد' : 'تعديل القسم'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ImageField(initialUrl: _image, folder: 'categories', onChanged: (u) => _image = u),
            const SizedBox(height: 12),
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'اسم القسم')),
            const SizedBox(height: 12),
            TextField(
              controller: _order,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(labelText: 'الترتيب (رقم)'),
            ),
            SwitchListTile(
              value: _active,
              onChanged: (v) => setState(() => _active = v),
              title: const Text('ظاهر للعملاء'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        TextButton(onPressed: _busy ? null : _save, child: const Text('حفظ')),
      ],
    );
  }
}

// ======================= وسائل الدفع =======================
class AdminPaymentsTab extends StatelessWidget {
  const AdminPaymentsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final list = context.watch<AppState>().payMethods;
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.gold,
        foregroundColor: Colors.black,
        onPressed: () => showDialog(context: context, builder: (_) => const PayDialog()),
        icon: const Icon(Icons.add),
        label: const Text('وسيلة دفع'),
      ),
      body: list.isEmpty
          ? const EmptyState('لم تُضف وسائل دفع بعد. لن تظهر للعملاء إلا بعد إضافتها وتفعيلها.')
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final m = list[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                      color: AppColors.card, borderRadius: BorderRadius.circular(14)),
                  child: ListTile(
                    title: Text(m.name),
                    subtitle: Text(m.active ? 'مفعّلة' : 'غير مفعّلة',
                        style: TextStyle(color: m.active ? Colors.greenAccent : AppColors.muted)),
                    onTap: () => showDialog(
                        context: context, builder: (_) => PayDialog(method: m)),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                      onPressed: () async {
                        if (!await confirmDialog(context, 'حذف "${m.name}"؟')) return;
                        try {
                          await Db.deletePay(m.id);
                        } catch (e) {
                          if (context.mounted) toast(context, 'تعذّر الحذف: $e');
                        }
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class PayDialog extends StatefulWidget {
  final PayMethod? method;
  const PayDialog({super.key, this.method});

  @override
  State<PayDialog> createState() => _PayDialogState();
}

class _PayDialogState extends State<PayDialog> {
  late final TextEditingController _name = TextEditingController(text: widget.method?.name ?? '');
  late final TextEditingController _ins =
      TextEditingController(text: widget.method?.instructions ?? '');
  late final TextEditingController _acc = TextEditingController(text: widget.method?.account ?? '');
  late bool _active = widget.method?.active ?? false;
  bool _busy = false;

  @override
  void dispose() {
    _name.dispose();
    _ins.dispose();
    _acc.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (_name.text.trim().isEmpty) {
      toast(context, 'اسم وسيلة الدفع مطلوب');
      return;
    }
    setState(() => _busy = true);
    try {
      await Db.savePay(widget.method?.id, {
        'name': _name.text.trim(),
        'instructions': _ins.text.trim(),
        'account': _acc.text.trim(),
        'active': _active,
      });
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) {
        toast(context, 'تعذّر الحفظ: $e');
        setState(() => _busy = false);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.method == null ? 'وسيلة دفع جديدة' : 'تعديل وسيلة الدفع'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: _name, decoration: const InputDecoration(labelText: 'الاسم')),
            const SizedBox(height: 12),
            TextField(
              controller: _ins,
              maxLines: 3,
              decoration: const InputDecoration(labelText: 'تعليمات التحويل'),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: _acc,
              decoration: const InputDecoration(labelText: 'رقم الحساب / معرّف الدفع'),
            ),
            SwitchListTile(
              value: _active,
              onChanged: (v) => setState(() => _active = v),
              title: const Text('مفعّلة (تظهر للعملاء)'),
            ),
          ],
        ),
      ),
      actions: [
        TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
        TextButton(onPressed: _busy ? null : _save, child: const Text('حفظ')),
      ],
    );
  }
}

// ======================= الإعدادات =======================
class AdminSettingsTab extends StatefulWidget {
  const AdminSettingsTab({super.key});

  @override
  State<AdminSettingsTab> createState() => _AdminSettingsTabState();
}

class _AdminSettingsTabState extends State<AdminSettingsTab> {
  late final TextEditingController _wa;
  late final TextEditingController _cur;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    final s = context.read<AppState>().settings;
    _wa = TextEditingController(text: s.whatsapp);
    _cur = TextEditingController(text: s.currency);
  }

  @override
  void dispose() {
    _wa.dispose();
    _cur.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await Db.saveSettings({
        'whatsapp': _wa.text.replaceAll(RegExp(r'[^0-9]'), ''),
        'currency': _cur.text.trim(),
      });
      if (mounted) toast(context, 'تم حفظ الإعدادات');
    } catch (e) {
      if (mounted) toast(context, 'تعذّر الحفظ: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        TextField(
          controller: _wa,
          keyboardType: TextInputType.phone,
          textDirection: TextDirection.ltr,
          decoration: const InputDecoration(
            labelText: 'رقم واتساب الدعم والطلبات',
            helperText: 'بصيغة دولية بدون + أو أصفار بادئة، مثال: 9665XXXXXXXX',
          ),
        ),
        const SizedBox(height: 12),
        TextField(
          controller: _cur,
          decoration: const InputDecoration(
            labelText: 'رمز العملة المعروض بجانب الأسعار',
            helperText: 'مثال: ر.س أو ج.م أو USD (يمكن تركه فارغًا)',
          ),
        ),
        const SizedBox(height: 20),
        ElevatedButton(
          onPressed: _busy ? null : _save,
          child: const Text('حفظ الإعدادات'),
        ),
      ],
    );
  }
}
