import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models.dart';
import '../../services/app_state.dart';
import '../../services/db.dart';
import '../../theme.dart';
import '../../widgets/common.dart';

class AdminProductsTab extends StatelessWidget {
  const AdminProductsTab({super.key});

  @override
  Widget build(BuildContext context) {
    final list = context.watch<AppState>().products;
    return Scaffold(
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.gold,
        foregroundColor: Colors.black,
        onPressed: () => Navigator.push(
            context, MaterialPageRoute(builder: (_) => const ProductForm())),
        icon: const Icon(Icons.add),
        label: const Text('منتج جديد'),
      ),
      body: list.isEmpty
          ? const EmptyState('لا توجد منتجات. أضف أول منتج من الزر بالأسفل.')
          : ListView.builder(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 90),
              itemCount: list.length,
              itemBuilder: (_, i) {
                final p = list[i];
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                      color: AppColors.card, borderRadius: BorderRadius.circular(14)),
                  child: ListTile(
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(10),
                      child: SizedBox(width: 52, height: 52, child: NetImage(p.imageUrl)),
                    ),
                    title: Text(p.name, maxLines: 1, overflow: TextOverflow.ellipsis),
                    subtitle: Text(
                        '${Money.fmt(p.price)}${p.active ? '' : '  •  مخفي'}',
                        style: const TextStyle(color: AppColors.gold)),
                    onTap: () => Navigator.push(context,
                        MaterialPageRoute(builder: (_) => ProductForm(product: p))),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline, color: Colors.redAccent),
                      onPressed: () async {
                        if (!await confirmDialog(context, 'حذف "${p.name}" نهائيًا؟')) return;
                        try {
                          await Db.deleteProduct(p.id);
                        } catch (e) {
                          if (context.mounted) toast(context, 'تعذّر الحذف: $e');
                        }
                      },
                    ),
                  ),
                );
              },
            ),
    );
  }
}

class _PackCtl {
  final TextEditingController label;
  final TextEditingController price;
  _PackCtl(String l, String p)
      : label = TextEditingController(text: l),
        price = TextEditingController(text: p);
  void dispose() {
    label.dispose();
    price.dispose();
  }
}

class ProductForm extends StatefulWidget {
  final Product? product;
  const ProductForm({super.key, this.product});

  @override
  State<ProductForm> createState() => _ProductFormState();
}

class _ProductFormState extends State<ProductForm> {
  final _form = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _desc;
  late final TextEditingController _price;
  late final TextEditingController _old;
  late String _categoryId;
  late String _type;
  late String _image;
  late bool _playerId;
  late bool _featured;
  late bool _top;
  late bool _active;
  final List<_PackCtl> _packs = [];
  bool _busy = false;

  String _n(double v) => v == v.roundToDouble() ? v.toStringAsFixed(0) : '$v';

  @override
  void initState() {
    super.initState();
    final p = widget.product;
    _name = TextEditingController(text: p?.name ?? '');
    _desc = TextEditingController(text: p?.description ?? '');
    _price = TextEditingController(text: p == null ? '' : _n(p.price));
    _old = TextEditingController(text: p?.oldPrice == null ? '' : _n(p!.oldPrice!));
    _categoryId = p?.categoryId ?? '';
    _type = p?.type ?? 'topup';
    _image = p?.imageUrl ?? '';
    _playerId = p?.requiresPlayerId ?? false;
    _featured = p?.featured ?? false;
    _top = p?.topSeller ?? false;
    _active = p?.active ?? true;
    for (final k in p?.packages ?? const <Pack>[]) {
      _packs.add(_PackCtl(k.label, _n(k.price)));
    }
  }

  @override
  void dispose() {
    _name.dispose();
    _desc.dispose();
    _price.dispose();
    _old.dispose();
    for (final p in _packs) {
      p.dispose();
    }
    super.dispose();
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final cats = context.read<AppState>().categories;
    if (cats.isNotEmpty && _categoryId.isEmpty) {
      toast(context, 'اختر القسم');
      return;
    }
    final price = parseNum(_price.text)!;
    final old = _old.text.trim().isEmpty ? null : parseNum(_old.text);
    if (_old.text.trim().isNotEmpty && old == null) {
      toast(context, 'السعر قبل الخصم غير صالح');
      return;
    }
    final packs = <Map<String, dynamic>>[];
    for (final k in _packs) {
      final l = k.label.text.trim();
      final raw = k.price.text.trim();
      if (l.isEmpty && raw.isEmpty) continue;
      final pr = parseNum(raw);
      if (l.isEmpty || pr == null) {
        toast(context, 'أكمل بيانات الباقات (الاسم والسعر)');
        return;
      }
      packs.add({'label': l, 'price': pr});
    }
    setState(() => _busy = true);
    try {
      await Db.saveProduct(widget.product?.id, {
        'name': _name.text.trim(),
        'description': _desc.text.trim(),
        'categoryId': _categoryId,
        'type': _type,
        'price': price,
        'oldPrice': old,
        'imageUrl': _image,
        'requiresPlayerId': _playerId,
        'featured': _featured,
        'topSeller': _top,
        'active': _active,
        'packages': packs,
      });
      if (mounted) Navigator.pop(context);
    } catch (e) {
      if (mounted) toast(context, 'تعذّر الحفظ: $e');
    }
    if (mounted) setState(() => _busy = false);
  }

  @override
  Widget build(BuildContext context) {
    final cats = context.watch<AppState>().categories;
    return Scaffold(
      appBar: AppBar(title: Text(widget.product == null ? 'منتج جديد' : 'تعديل المنتج')),
      body: Form(
        key: _form,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            ImageField(
                initialUrl: _image, folder: 'products', onChanged: (u) => _image = u),
            const SizedBox(height: 16),
            TextFormField(
              controller: _name,
              decoration: const InputDecoration(labelText: 'اسم المنتج'),
              validator: (v) => (v == null || v.trim().isEmpty) ? 'مطلوب' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _desc,
              maxLines: 4,
              decoration: const InputDecoration(labelText: 'الوصف والتفاصيل'),
            ),
            const SizedBox(height: 16),
            const Text('القسم', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            if (cats.isEmpty)
              const Text('أنشئ الأقسام أولًا من تبويب "الأقسام".',
                  style: TextStyle(color: AppColors.muted))
            else
              Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  for (final c in cats)
                    ChoiceChip(
                      label: Text(c.name),
                      selected: _categoryId == c.id,
                      selectedColor: AppColors.gold.withAlpha(60),
                      onSelected: (_) => setState(() => _categoryId = c.id),
                    ),
                ],
              ),
            const SizedBox(height: 16),
            const Text('نوع المنتج', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            Wrap(
              spacing: 8,
              children: [
                for (final e in productTypes.entries)
                  ChoiceChip(
                    label: Text(e.value),
                    selected: _type == e.key,
                    selectedColor: AppColors.gold.withAlpha(60),
                    onSelected: (_) => setState(() => _type = e.key),
                  ),
              ],
            ),
            const SizedBox(height: 16),
            TextFormField(
              controller: _price,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                  labelText: 'السعر', helperText: 'مع وجود باقات: ضع أقل سعر كسعر أساسي'),
              validator: (v) => parseNum(v ?? '') == null ? 'أدخل سعرًا صحيحًا' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _old,
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              decoration: const InputDecoration(
                  labelText: 'السعر قبل الخصم (اختياري)',
                  helperText: 'إذا كان أعلى من السعر يظهر المنتج في العروض والخصومات'),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                const Expanded(
                    child: Text('الباقات (اختياري)',
                        style: TextStyle(fontWeight: FontWeight.w700))),
                TextButton.icon(
                  onPressed: () => setState(() => _packs.add(_PackCtl('', ''))),
                  icon: const Icon(Icons.add),
                  label: const Text('إضافة باقة'),
                ),
              ],
            ),
            for (var i = 0; i < _packs.length; i++)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(
                  children: [
                    Expanded(
                      flex: 3,
                      child: TextField(
                        controller: _packs[i].label,
                        decoration: const InputDecoration(hintText: 'اسم الباقة'),
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      flex: 2,
                      child: TextField(
                        controller: _packs[i].price,
                        keyboardType:
                            const TextInputType.numberWithOptions(decimal: true),
                        decoration: const InputDecoration(hintText: 'السعر'),
                      ),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.redAccent),
                      onPressed: () => setState(() {
                        _packs[i].dispose();
                        _packs.removeAt(i);
                      }),
                    ),
                  ],
                ),
              ),
            SwitchListTile(
              value: _playerId,
              onChanged: (v) => setState(() => _playerId = v),
              title: const Text('يتطلب معرّف اللاعب (ID)'),
            ),
            SwitchListTile(
              value: _featured,
              onChanged: (v) => setState(() => _featured = v),
              title: const Text('عرض ضمن العروض المميزة'),
            ),
            SwitchListTile(
              value: _top,
              onChanged: (v) => setState(() => _top = v),
              title: const Text('عرض ضمن الأكثر طلبًا'),
            ),
            SwitchListTile(
              value: _active,
              onChanged: (v) => setState(() => _active = v),
              title: const Text('ظاهر للعملاء'),
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _busy ? null : _save,
              child: _busy
                  ? const SizedBox(
                      width: 22,
                      height: 22,
                      child: CircularProgressIndicator(strokeWidth: 2, color: Colors.black))
                  : const Text('حفظ'),
            ),
          ],
        ),
      ),
    );
  }
}
