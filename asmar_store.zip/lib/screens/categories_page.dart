import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'products_page.dart';

class CategoriesPage extends StatelessWidget {
  const CategoriesPage({super.key});

  Widget _tile(BuildContext context,
      {required String title, String image = '', required VoidCallback onTap, IconData? icon}) {
    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: onTap,
      child: Container(
        decoration: BoxDecoration(
          color: AppColors.card,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: AppColors.gold.withAlpha(60)),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (image.isNotEmpty) NetImage(image),
            Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [Colors.transparent, Colors.black.withAlpha(200)],
                ),
              ),
            ),
            if (image.isEmpty)
              Center(
                  child: Icon(icon ?? Icons.sports_esports,
                      size: 40, color: AppColors.gold.withAlpha(160))),
            Positioned(
              left: 10,
              right: 10,
              bottom: 10,
              child: Text(title,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final cats = context.watch<AppState>().categories.where((c) => c.active).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('الأقسام')),
      body: GridView.count(
        padding: const EdgeInsets.all(16),
        crossAxisCount: 2,
        crossAxisSpacing: 12,
        mainAxisSpacing: 12,
        childAspectRatio: 1.1,
        children: [
          for (final c in cats)
            _tile(
              context,
              title: c.name,
              image: c.imageUrl,
              onTap: () => Navigator.push(
                context,
                MaterialPageRoute(
                    builder: (_) =>
                        ProductsPage(title: c.name, filter: (p) => p.categoryId == c.id)),
              ),
            ),
          _tile(
            context,
            title: 'العروض والخصومات',
            icon: Icons.local_offer,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (_) => ProductsPage(
                      title: 'العروض والخصومات', filter: (p) => p.hasDiscount)),
            ),
          ),
        ],
      ),
    );
  }
}
