import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models.dart';
import '../services/app_state.dart';
import '../theme.dart';
import '../widgets/common.dart';
import 'auth_page.dart';
import 'order_page.dart';

class ProductPage extends StatefulWidget {
  final Product product;
  const ProductPage({super.key, required this.product});

  @override
  State<ProductPage> createState() => _ProductPageState();
}

class _ProductPageState extends State<ProductPage> {
  Pack? _pack;
  int _qty = 1;

  @override
  void initState() {
    super.initState();
    if (widget.product.packages.isNotEmpty) _pack = widget.product.packages.first;
  }

  double get _unit => _pack?.price ?? widget.product.price;

  Future<void> _order() async {
    final s = context.read<AppState>();
    if (s.user == null) {
      final ok = await Navigator.push<bool>(
          context, MaterialPageRoute(builder: (_) => const AuthPage()));
      if (ok != true || !mounted) return;
    }
    Navigator.push(
      context,
      MaterialPageRoute(
          builder: (_) => OrderPage(product: widget.product, pack: _pack, qty: _qty)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.product;
    return Scaffold(
      body: CustomScrollView(
        slivers: [
          SliverAppBar(
            pinned: true,
            expandedHeight: 300,
            flexibleSpace: FlexibleSpaceBar(background: NetImage(p.imageUrl)),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(p.name,
                      style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      Text(Money.fmt(p.price),
                          style: const TextStyle(
                              color: AppColors.gold,
                              fontSize: 20,
                              fontWeight: FontWeight.w800)),
                      if (p.hasDiscount) ...[
                        const SizedBox(width: 10),
                        Text(Money.fmt(p.oldPrice!),
                            style: const TextStyle(
                                color: AppColors.muted,
                                decoration: TextDecoration.lineThrough)),
                      ],
                      const Spacer(),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                            color: AppColors.card2,
                            borderRadius: BorderRadius.circular(20)),
                        child: Text(productTypes[p.type] ?? '',
                            style: const TextStyle(fontSize: 12)),
                      ),
                    ],
                  ),
                  if (p.description.isNotEmpty) ...[
                    const SizedBox(height: 16),
                    Text(p.description, style: const TextStyle(height: 1.7)),
                  ],
                  if (p.packages.isNotEmpty) ...[
                    const SizedBox(height: 20),
                    const Text('اختر الباقة',
                        style: TextStyle(fontWeight: FontWeight.w700)),
                    const SizedBox(height: 8),
                    Wrap(
                      spacing: 8,
                      runSpacing: 8,
                      children: [
                        for (final k in p.packages)
                          ChoiceChip(
                            label: Text('${k.label} • ${Money.fmt(k.price)}'),
                            selected: _pack == k,
                            selectedColor: AppColors.gold.withAlpha(60),
                            onSelected: (_) => setState(() => _pack = k),
                          ),
                      ],
                    ),
                  ],
                  const SizedBox(height: 20),
                  Row(
                    children: [
                      const Text('الكمية', style: TextStyle(fontWeight: FontWeight.w700)),
                      const Spacer(),
                      IconButton.outlined(
                        onPressed: _qty > 1 ? () => setState(() => _qty--) : null,
                        icon: const Icon(Icons.remove),
                      ),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: Text('$_qty',
                            style: const TextStyle(
                                fontSize: 18, fontWeight: FontWeight.w700)),
                      ),
                      IconButton.outlined(
                        onPressed: _qty < 99 ? () => setState(() => _qty++) : null,
                        icon: const Icon(Icons.add),
                      ),
                    ],
                  ),
                  if (p.requiresPlayerId) ...[
                    const SizedBox(height: 12),
                    const Text('هذه الخدمة تتطلب معرّف اللاعب (ID) في الخطوة التالية.',
                        style: TextStyle(color: AppColors.muted, fontSize: 12)),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 10, 16, 10),
          decoration: const BoxDecoration(
              color: Color(0xFF111111),
              border: Border(top: BorderSide(color: Color(0x33E0B83A)))),
          child: Row(
            children: [
              Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('الإجمالي',
                      style: TextStyle(color: AppColors.muted, fontSize: 12)),
                  Text(Money.fmt(_unit * _qty),
                      style: const TextStyle(
                          color: AppColors.gold,
                          fontSize: 18,
                          fontWeight: FontWeight.w800)),
                ],
              ),
              const SizedBox(width: 16),
              Expanded(child: ElevatedButton(onPressed: _order, child: const Text('اطلب الآن'))),
            ],
          ),
        ),
      ),
    );
  }
}
