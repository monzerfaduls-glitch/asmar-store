import 'package:flutter/material.dart';
import '../theme.dart';
import '../widgets/common.dart';

class SetupNeeded extends StatelessWidget {
  const SetupNeeded({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: const [
              Logo(size: 32),
              SizedBox(height: 32),
              Icon(Icons.settings_suggest, color: AppColors.gold, size: 56),
              SizedBox(height: 16),
              Text('لم يتم ربط التطبيق بـ Firebase بعد',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
              SizedBox(height: 8),
              Text(
                'أضف مفاتيح Firebase وقت البناء (راجع ملف README_AR.md)، ثم أعد بناء التطبيق.',
                textAlign: TextAlign.center,
                style: TextStyle(color: AppColors.muted),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
