import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:image_picker/image_picker.dart';
import '../models.dart';

class Db {
  static FirebaseFirestore get _fs => FirebaseFirestore.instance;

  // ---------- قراءة عامة ----------
  static Stream<StoreSettings> settings() => _fs
      .doc('settings/store')
      .snapshots()
      .map((s) => StoreSettings.fromMap(s.data()));

  static Stream<List<Category>> categories() =>
      _fs.collection('categories').snapshots().map((s) {
        final l = s.docs.map(Category.fromDoc).toList();
        l.sort((a, b) => a.order.compareTo(b.order));
        return l;
      });

  static Stream<List<Product>> products() => _fs
      .collection('products')
      .snapshots()
      .map((s) => s.docs.map(Product.fromDoc).toList());

  static Stream<List<PayMethod>> payMethods() => _fs
      .collection('paymentMethods')
      .snapshots()
      .map((s) => s.docs.map(PayMethod.fromDoc).toList());

  // ---------- المستخدم ----------
  static Future<bool> isAdmin(String uid) async {
    try {
      return (await _fs.doc('admins/$uid').get()).exists;
    } catch (_) {
      return false;
    }
  }

  static Future<UserProfile?> profile(String uid) async {
    try {
      final d = await _fs.doc('users/$uid').get();
      if (!d.exists) return null;
      return UserProfile.fromMap(d.data()!);
    } catch (_) {
      return null;
    }
  }

  static Future<void> saveProfile(
          String uid, String name, String phone, String email) =>
      _fs.doc('users/$uid').set({
        'name': name,
        'phone': phone,
        'email': email,
        'createdAt': FieldValue.serverTimestamp(),
      });

  // ---------- الطلبات ----------
  static String makeRef() {
    final t = DateTime.now().millisecondsSinceEpoch.toRadixString(36).toUpperCase();
    final r = Random().nextInt(1296).toRadixString(36).toUpperCase().padLeft(2, '0');
    return 'AS-$t$r';
  }

  static List<AppOrder> _orders(QuerySnapshot<Map<String, dynamic>> s) {
    final l = s.docs.map(AppOrder.fromDoc).toList();
    final now = DateTime.now();
    l.sort((a, b) => (b.createdAt ?? now).compareTo(a.createdAt ?? now));
    return l;
  }

  static Stream<List<AppOrder>> ordersForUser(String uid) => _fs
      .collection('orders')
      .where('userId', isEqualTo: uid)
      .snapshots()
      .map(_orders);

  static Stream<List<AppOrder>> allOrders() =>
      _fs.collection('orders').snapshots().map(_orders);

  static Stream<AppOrder?> orderStream(String id) => _fs
      .doc('orders/$id')
      .snapshots()
      .map((d) => d.exists ? AppOrder.fromDoc(d) : null);

  static Future<String> createOrder(Map<String, dynamic> data) async {
    final doc = await _fs.collection('orders').add({
      ...data,
      'status': 'review',
      'createdAt': FieldValue.serverTimestamp(),
    });
    return doc.id;
  }

  static Future<void> setStatus(String id, String status) => _fs
      .doc('orders/$id')
      .update({'status': status, 'updatedAt': FieldValue.serverTimestamp()});

  static Future<void> setProof(String id, String url) =>
      _fs.doc('orders/$id').update({'proofUrl': url});

  // ---------- الإدارة ----------
  static Future<void> saveProduct(String? id, Map<String, dynamic> data) {
    if (id == null) {
      return _fs.collection('products').add({
        ...data,
        'createdAt': FieldValue.serverTimestamp(),
      });
    }
    return _fs.doc('products/$id').update(data);
  }

  static Future<void> deleteProduct(String id) => _fs.doc('products/$id').delete();

  static Future<void> saveCategory(String? id, Map<String, dynamic> data) {
    if (id == null) return _fs.collection('categories').add(data);
    return _fs.doc('categories/$id').update(data);
  }

  static Future<void> deleteCategory(String id) => _fs.doc('categories/$id').delete();

  static Future<void> savePay(String? id, Map<String, dynamic> data) {
    if (id == null) return _fs.collection('paymentMethods').add(data);
    return _fs.doc('paymentMethods/$id').update(data);
  }

  static Future<void> deletePay(String id) => _fs.doc('paymentMethods/$id').delete();

  static Future<void> saveSettings(Map<String, dynamic> data) =>
      _fs.doc('settings/store').set(data, SetOptions(merge: true));

  // ---------- الصور ----------
  static Future<String> uploadImage(XFile file, String path) async {
    final bytes = await file.readAsBytes();
    var type = file.mimeType ?? 'image/jpeg';
    if (!type.startsWith('image/')) type = 'image/jpeg';
    final ref = FirebaseStorage.instance.ref(path);
    await ref.putData(bytes, SettableMetadata(contentType: type));
    return ref.getDownloadURL();
  }
}
