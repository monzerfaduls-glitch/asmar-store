import 'dart:async';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/foundation.dart';
import '../models.dart';
import 'db.dart';

class AppState extends ChangeNotifier {
  User? user;
  bool isAdmin = false;
  UserProfile? profile;
  StoreSettings settings = const StoreSettings();
  List<Category> categories = [];
  List<Product> products = [];
  List<PayMethod> payMethods = [];
  String? error;
  bool productsLoaded = false;

  final List<StreamSubscription> _subs = [];
  int _seq = 0;

  AppState() {
    _subs.add(Db.settings().listen((s) {
      settings = s;
      Money.currency = s.currency;
      notifyListeners();
    }, onError: _onErr));
    _subs.add(Db.categories().listen((l) {
      categories = l;
      notifyListeners();
    }, onError: _onErr));
    _subs.add(Db.products().listen((l) {
      products = l;
      productsLoaded = true;
      notifyListeners();
    }, onError: _onErr));
    _subs.add(Db.payMethods().listen((l) {
      payMethods = l;
      notifyListeners();
    }, onError: _onErr));
    _subs.add(FirebaseAuth.instance.authStateChanges().listen((u) {
      user = u;
      isAdmin = false;
      profile = null;
      notifyListeners();
      if (u != null) _loadUserData(u.uid);
    }));
  }

  void _onErr(Object e) {
    error = e.toString();
    notifyListeners();
  }

  List<Product> get activeProducts => products.where((p) => p.active).toList();

  List<PayMethod> get activePayMethods => payMethods.where((m) => m.active).toList();

  Future<void> _loadUserData(String uid) async {
    final seq = ++_seq;
    final admin = await Db.isAdmin(uid);
    final prof = await Db.profile(uid);
    if (seq != _seq || user?.uid != uid) return;
    isAdmin = admin;
    profile = prof;
    notifyListeners();
  }

  Future<void> signIn(String email, String pass) =>
      FirebaseAuth.instance.signInWithEmailAndPassword(email: email, password: pass);

  Future<void> signUp(String name, String phone, String email, String pass) async {
    final c = await FirebaseAuth.instance
        .createUserWithEmailAndPassword(email: email, password: pass);
    await Db.saveProfile(c.user!.uid, name, phone, email);
    await _loadUserData(c.user!.uid);
  }

  Future<void> signOut() => FirebaseAuth.instance.signOut();

  String get displayName =>
      profile?.name.isNotEmpty == true ? profile!.name : (user?.email ?? '');

  @override
  void dispose() {
    for (final s in _subs) {
      s.cancel();
    }
    super.dispose();
  }
}
