"""يُشغَّل في GitHub Actions بعد flutter create:
- يضيف صلاحية الإنترنت (ضرورية لنسخة release)
- يسمح بفتح روابط واتساب
- يضبط اسم التطبيق
- يرفع minSdk إلى 23 (مطلوب لمكتبات Firebase)
"""
import pathlib
import re

manifest = pathlib.Path('android/app/src/main/AndroidManifest.xml')
t = manifest.read_text(encoding='utf-8')

if 'android.permission.INTERNET' not in t:
    t = re.sub(r'(<manifest[^>]*>)',
               r'\1\n    <uses-permission android:name="android.permission.INTERNET"/>',
               t, count=1)

queries = ('<intent><action android:name="android.intent.action.VIEW"/>'
           '<data android:scheme="https"/></intent>'
           '<intent><action android:name="android.intent.action.VIEW"/>'
           '<data android:scheme="whatsapp"/></intent>')
if '</queries>' in t:
    t = t.replace('</queries>', queries + '</queries>', 1)
else:
    t = t.replace('</manifest>', '<queries>' + queries + '</queries>\n</manifest>', 1)

t = re.sub(r'android:label="[^"]*"', 'android:label="متجر أسمر"', t, count=1)
manifest.write_text(t, encoding='utf-8')

for name in ('build.gradle.kts', 'build.gradle'):
    f = pathlib.Path('android/app') / name
    if f.exists():
        g = f.read_text(encoding='utf-8')
        g = re.sub(r'(minSdk(?:Version)?)(\s*=\s*|\s+)flutter\.minSdkVersion',
                   r'\1\g<2>23', g)
        f.write_text(g, encoding='utf-8')
print('android patched')
